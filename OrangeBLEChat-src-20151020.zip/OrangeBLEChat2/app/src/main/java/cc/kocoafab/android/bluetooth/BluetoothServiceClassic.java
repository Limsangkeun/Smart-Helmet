/*
    Copyright (c) 2005 nepes, kocoafab
    See the file license.txt for copying permission.
 */
package cc.kocoafab.android.bluetooth;

import android.content.Context;

public class BluetoothServiceClassic {

    public void initialize(Context context) {

    }
}
