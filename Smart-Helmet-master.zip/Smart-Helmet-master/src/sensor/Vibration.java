package sensor;

public class Vibration {

	private String userID;
	private int OutputVibration;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getOutputVibration() {
		return OutputVibration;
	}
	public void setOutputVibration(int outputVibration) {
		OutputVibration = outputVibration;
	}
	
}
