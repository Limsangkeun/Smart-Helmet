package sensor;

public class Distance {
	
	private String userID;
	private int InputDistanceMeasure;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getInputDistanceMeasure() {
		return InputDistanceMeasure;
	}
	public void setInputDistanceMeasure(int inputDistanceMeasure) {
		InputDistanceMeasure = inputDistanceMeasure;
	}
	
}
