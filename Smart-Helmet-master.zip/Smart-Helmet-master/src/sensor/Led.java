package sensor;

public class Led {
	private String userID;
	private int OutputLED;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getOutputLED() {
		return OutputLED;
	}
	public void setOutputLED(int outputLED) {
		OutputLED = outputLED;
	}
	
}
