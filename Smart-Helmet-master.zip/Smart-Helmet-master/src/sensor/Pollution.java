package sensor;

public class Pollution {
	
	private String userID;
	private int InputPollutionMeasure;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getInputPollutionMeasure() {
		return InputPollutionMeasure;
	}
	public void setInputPollutionMeasure(int inputPollutionMeasure) {
		InputPollutionMeasure = inputPollutionMeasure;
	}	
	
}
