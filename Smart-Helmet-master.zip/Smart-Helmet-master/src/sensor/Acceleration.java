package sensor;

public class Acceleration {
	
	private String userID;
	private int InputAccelerationMeasure;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public int getInputAccelerationMeasure() {
		return InputAccelerationMeasure;
	}
	public void setInputAccelerationMeasure(int inputAccelerationMeasure) {
		InputAccelerationMeasure = inputAccelerationMeasure;
	}
}
