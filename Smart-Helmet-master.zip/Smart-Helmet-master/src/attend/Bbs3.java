package attend;

public class Bbs3 {
   
   private int bbsID2;
   private String bbsTitle2;
   private String userID2;
   private String bbsDate2;
   private String bbsContent2;
   private String attendTime;
   private String closeTime;
   private int bbsAvailable2;
   
   
   
   
   public String getAttendTime() {
      return attendTime;
   }
   public void setAttendTime(String attendTime) {
      this.attendTime = attendTime;
   }
   public String getCloseTime() {
      return closeTime;
   }
   public void setCloseTime(String closeTime) {
      this.closeTime = closeTime;
   }

   public int getBbsID2() {
      return bbsID2;
   }
   public void setBbsID2(int bbsID) {
      this.bbsID2 = bbsID;
   }
   
   public String getUserID2() {
      return userID2;
   }
   public void setUserID2(String userID2) {
      this.userID2 = userID2;
   }

   public int getBbsAvailable2() {
      return bbsAvailable2;
   }
   public void setBbsAvailable2(int bbsAvailable2) {
      this.bbsAvailable2 = bbsAvailable2;
   }
   
}