package JSP;

public class Commute {
	String userID;
	String date;
	String attendtime;
	String closetime;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getAttendtime() {
		return attendtime;
	}
	public void setAttendtime(String attendtime) {
		this.attendtime = attendtime;
	}
	public String getClosetime() {
		return closetime;
	}
	public void setClosetime(String closetime) {
		this.closetime = closetime;
	}
}
