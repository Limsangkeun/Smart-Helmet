package com.example.sangkeunlim.smartsafetyhelmetv2;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends Activity {
    EditText ID2, PW2, NAME, AGE, PHONE;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ID2 = (EditText) findViewById(R.id.E_ID2);
        PW2 = (EditText) findViewById(R.id.E_PW2);
        NAME = (EditText) findViewById(R.id.NAME);
        AGE = (EditText) findViewById(R.id.AGE);
        PHONE = (EditText) findViewById(R.id.E_PHONE);

        Button Back = (Button) findViewById(R.id.B_BACK);

        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent BackIntent = new Intent(RegisterActivity.this, MainActivity.class);
                RegisterActivity.this.startActivity(BackIntent);
            }
        });
    }
        private void Register(){
        String id = ID2.getText().toString();
        String pw = PW2.getText().toString();
        String age = AGE.getText().toString();
        String name = NAME.getText().toString();
        String phone = PHONE.getText().toString();
    }

}
