package bbs2;

public class Bbs2 {
	
	private int bbsID2;
	private String bbsTitle2;
	private String userID2;
	private String bbsDate2;
	private String bbsContent2;
	private int bbsAvailable2;
	
	public int getBbsID2() {
		return bbsID2;
	}
	public void setBbsID2(int bbsID) {
		this.bbsID2 = bbsID;
	}
	public String getBbsTitle2() {
		return bbsTitle2;
	}
	public void setBbsTitle2(String bbsTitle2) {
		this.bbsTitle2 = bbsTitle2;
	}
	public String getUserID2() {
		return userID2;
	}
	public void setUserID2(String userID2) {
		this.userID2 = userID2;
	}
	public String getBbsDate2() {
		return bbsDate2;
	}
	public void setBbsDate2(String bbsDate2) {
		this.bbsDate2 = bbsDate2;
	}
	public String getBbsContent2() {
		return bbsContent2;
	}
	public void setBbsContent2(String bbsContent2) {
		this.bbsContent2 = bbsContent2;
	}
	public int getBbsAvailable2() {
		return bbsAvailable2;
	}
	public void setBbsAvailable2(int bbsAvailable2) {
		this.bbsAvailable2 = bbsAvailable2;
	}
	
}
